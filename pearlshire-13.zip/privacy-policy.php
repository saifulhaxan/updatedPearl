<!DOCTYPE html>
<html>
<title> Our Values - PearlShire </title>
<?php include 'headLinks.php' ?>

<body>
  <?php include 'navigation.php'; ?>
  <section class="contentSection">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="titleHead text-center">
            <h3>Privacy Policy</h3>
          </div>
        </div>
        <div class="col-md-12">
          <div class="contentBox">
            <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
            <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
            <ol>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
              <li>
                <h4>Where can I get some? </h4>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

              </li>
            </ol>
            <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
          </div>
        </div>
      </div>
    </div>

  </section>
  <?php include 'footer.php' ?>
</body>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/studio-freight/lenis@1.0.19/bundled/lenis.min.js"></script>
<script src="assets/js/custom.js"></script> -->

<script type="text/javascript">
  $(document).ready(function() {
    var currentSlide = 0;
    var totalSlides = $('.slide').length;
    var isAnimating = false;

    function updateSlides() {
      // Remove all classes before reassigning
      $('.slide').removeClass('active ahead next behind');
      // Add 'behind' class to all previous slides
      $('.slide').slice(0, currentSlide).addClass('behind');
      // Add 'active' class to the current slide
      $('.slide').eq(currentSlide).addClass('active');
      // Add 'next' class to the next slide
      if (currentSlide + 1 < totalSlides) {
        $('.slide').eq(currentSlide + 1).addClass('next').addClass('ahead');
      }
      // Add 'ahead' class to slides after the next one
      $('.slide').slice(currentSlide + 2).addClass('ahead');
      // Update the SlideBar text
      $('.SlideBar__prev').text('0' + (currentSlide + 1));
      $('.SlideBar__next').text('0' + (currentSlide + 2));
    }

    function animateSlide(direction) {
      if (isAnimating) return; // Prevent multiple animations at the same time
      if (direction === 'next' && currentSlide < totalSlides - 1) {
        currentSlide++;
      } else if (direction === 'prev' && currentSlide > 0) {
        currentSlide--;
      }
      isAnimating = true;
      updateSlides();
      gsap.fromTo('.slide.active .slide__container', {
        opacity: 0
      }, {
        opacity: 1,
        duration: 1
      });
      gsap.fromTo('.slide.active .slide__image img', {
        scale: 1.1
      }, {
        scale: 1,
        duration: 1,
        onComplete: function() {
          isAnimating = false; // Allow new animations after the current one completes
        }
      });
    }
    $('.buttons__next').click(function() {
      animateSlide('next');
    });
    $('.buttons__prev').click(function() {
      animateSlide('prev');
    });
    // GSAP ScrollTrigger to pin the about section and start animations when fully in view
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.create({
      trigger: "#about_section_two",
      start: "top top", // Start when the top of #about_section_two hits the top of the viewport
      end: "+=1500", // Extend the pin duration by 1000px
      pin: true, // Pin the section
      onEnter: () => {
        // Re-attach the wheel event listener when the section is fully in view
        $(window).on('wheel', function(event) {
          if (event.originalEvent.deltaY > 1) {
            animateSlide('next'); // Scroll down to go to the next slide
          } else {
            animateSlide('prev'); // Scroll up to go to the previous slide
          }
        });
      },
      onLeaveBack: () => {
        // Optionally detach the event listener when the section leaves the viewport
        $(window).off('wheel');
      }
    });
    updateSlides(); // Initialize the first slide
  });
</script>

</html>